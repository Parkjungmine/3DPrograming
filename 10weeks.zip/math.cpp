#include <iostream>
#include "MuSoenMath.h"

int main()
{
	Park();

	system("pause");


}